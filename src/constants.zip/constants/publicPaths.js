  const UNAUTHORIZED_PATHS = [
 "/qa-api/auth/signin",
  ];
  module.exports = UNAUTHORIZED_PATHS;
